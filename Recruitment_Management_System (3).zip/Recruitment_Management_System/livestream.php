<!DOCTYPE html>
<?php
    session_start();
    include('admin/db_connect.php');
    ob_start();
    $query = $conn->query("SELECT * FROM system_settings limit 1")->fetch_array();
     foreach ($query as $key => $value) {
      if(!is_numeric($key))
        $_SESSION['setting_'.$key] = $value;
    }
    ob_end_flush();
    include('header.php');

	
    ?>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Agora Demo</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='css/style.css'>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300&family=Permanent+Marker&display=swap" rel="stylesheet">
</head>
<body>

    <main>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="./"><?php echo $_SESSION['setting_name'] ?></a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="index.php?page=home">Home</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="index.php?page=about">About</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="livestream.php?page=about">livestream</a></li>
                        
                     
                    </ul>
                </div>
            </div>
        </nav>

     


        <!-- <div id="users-list"></div> -->

        <h1 id="site-title">Streams</h1>
        <div id="join-wrapper">
            <input id="username" type="text" placeholder="Enter your name..." />
            <button id="join-btn">Join Stream</button>
        </div>
        <div id="user-streams" ></div>
        


        <!-- Wrapper for join button -->
        <div id="footer">
            <div class="icon-wrapper">
                <img class="control-icon" id="camera-btn" src="./assets/img/video.svg" />
                <p>Cam</p>
            </div>

            <div class="icon-wrapper">
                <img class="control-icon" id="mic-btn" src="./assets/img/microphone.svg" />
                <p>Mic</p>
            </div>

            <div class="icon-wrapper">
                <img class="control-icon" id="leave-btn" src="./assets/img/leave.svg" />
                <p>Leave</p>
            </div>
            
           
            
            
        </div>

    </main>

    <script src="https://download.agora.io/sdk/release/AgoraRTC_N.js"></script>
    <script src='js/script.js'></script>
</body>
</html>